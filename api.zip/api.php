<?php

if ($_SERVER['REQUEST_METHOD'] != 'POST'){
    header("HTTP/1.0 404 Not Found");
    echo "<html><head><title>404 Not Found</title></head>
    <body bgcolor='white'>
    <center><h1>404 Not Found</h1></center>
    <hr><center>nginx/1.14.0 (Ubuntu)</center>

    <!-- a padding to disable MSIE and Chrome friendly error page -->
    <!-- a padding to disable MSIE and Chrome friendly error page -->
    <!-- a padding to disable MSIE and Chrome friendly error page -->
    <!-- a padding to disable MSIE and Chrome friendly error page -->
    <!-- a padding to disable MSIE and Chrome friendly error page -->
    <!-- a padding to disable MSIE and Chrome friendly error page -->
    </body></html>";
    return;
}

$uuid = $_POST['uuid'];
$user_id = $_POST['user_id'];
echo shell_exec("/usr/local/x-ui/bin/api api adi --server=127.0.0.1:8080 --uuid=$uuid --id=$user_id");

?>