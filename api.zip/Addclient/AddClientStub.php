<?php
// GENERATED CODE -- DO NOT EDIT!

namespace Addclient;

/**
 * The greeting service definition.
 */
class AddClientStub {

    /**
     * Sends a greeting
     * @param \Addclient\ServerRequest $request client request
     * @param \Grpc\ServerContext $context server request context
     * @return \Addclient\ServerResponse for response data, null if if error occured
     *     initial metadata (if any) and status (if not ok) should be set to $context
     */
    public function sendRequest(
        \Addclient\ServerRequest $request,
        \Grpc\ServerContext $context
    ): ?\Addclient\ServerResponse {
        $context->setStatus(\Grpc\Status::unimplemented());
        return null;
    }

    /**
     * Get the method descriptors of the service for server registration
     *
     * @return array of \Grpc\MethodDescriptor for the service methods
     */
    public final function getMethodDescriptors(): array
    {
        return [
            '/addclient.AddClient/sendRequest' => new \Grpc\MethodDescriptor(
                $this,
                'sendRequest',
                '\Addclient\ServerRequest',
                \Grpc\MethodDescriptor::UNARY_CALL
            ),
        ];
    }

}
