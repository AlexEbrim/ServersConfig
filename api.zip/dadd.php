<?php

require dirname(__FILE__).'/vendor/autoload.php';
@include_once dirname(__FILE__).'/Addclient/AddClientClient.php';
@include_once dirname(__FILE__).'/Addclient/ServerRequest.php';
@include_once dirname(__FILE__).'/Addclient/ServerResponse.php';

function requestAddClient($id, $email)
{
    $client = new Addclient\AddClientClient('localhost:5000', [
        'credentials' => Grpc\ChannelCredentials::createInsecure(),
    ]);
    
    $request = new Addclient\ServerRequest();
    $request->setUuid($id);
    $request->setEmail($email);
    
    list($response, $status) = $client->sendRequest($request)->wait();
    if ($status->code == Grpc\STATUS_OK) {
        echo $response->getMessage() . PHP_EOL;
    }
}

if($argv[1] == 'fbguaejhfWUHIUKCorw452iklscjscojcs458csfcs'){
	$uuid = $argv[2];
    $user_id = $argv[3];
    requestAddClient($uuid, $user_id);
}


